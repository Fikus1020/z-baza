<?php
    session_start(); //niezbędne polecenie, tworzy sesje
    $conn = new mysqli("172.16.131.125","02_pelka","kasztany12","02_pelka");

    //dane do logowania z formularza odbierane metoda POST
    $login = $_POST['login'];
    $haslo = $_POST['haslo'];

    //=================WERSJA Z BAZA DANYCH!=================

    //w bazie danych istnieje tabela "users" z nastepujaca struktura:
    //id_user[int(16)] | login[varchar(64)] | password[varchar(128)]

    //kolumna "password" ma przydzielone 128 znakow ze wzgledu na
    //wprowadzenie szyfrowania hasla, jest to wazne, zeby uniknac
    //pozniejszych bledow np. przy wprowadzaniu danych
    //oczywiscie mozna rowniez ustawic zmienne jako "text" zamiast "varchar"



    //jezeli zmienna "zalogowany" nie jest ustawiona,
    //czyli uzytkownik nie jest zalogowany
    if(!isset($_SESSION['zalogowany'])){

        // wyciagnij haslo z tabeli "users" gdzie login jest równy $login
        // - czyli loginowi, ktory podalismy w formularzu
        $sql = "SELECT password FROM users WHERE login = \"".$login."\"";
        $result = mysqli_query($conn, $sql);

        //jezeli polecenie sie wykona
        if($query = mysqli_fetch_assoc($result)){

            //jezeli haslo, ktore wprowadzilismy w formularzu, dodatkowo zaszyfrowane metoda md5, jest poprawne
            if($query['password'] == md5($haslo)){

                //ustaw "zalogowany" na 1
                $_SESSION['zalogowany'] = 1;

                //przekieruj mnie do index.php
                header('location: index.php');
            }

            //jezeli haslo nie jest poprawne
            else {

                //przekieruj mnie do index.php, ale nie ustawiaj
                //zmiennej "zalogowany" wcale
                header('location: index.php');
            }
        }
    }

    //jezeli zmienna "zalogowany" jest ustawiona
    else {

        //przekieruj mnie do index.php, bo jestem juz zalogowany
        header('location: index.php');
    }
?>