<?php
    session_start(); //niezbędne polecenie, tworzy sesje
    $conn = new mysqli("172.16.131.125","02_pelka","kasztany12","02_pelka");


?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="main.css">
    <title>index.php</title>
</head>
<body>
    <?php

    //jezeli zmienna "zalogowany" nie jest ustawiona
    if(!isset($_SESSION['zalogowany'])){
    ?>

        <!-- to wyswietl formularz logowania -->
        <div class="logowanie">
            <form action="logowanie.php" method="post">
                <input type="text" name="login" placeholder="Login">
                <input type="password" name="haslo" placeholder="Hasło">
                <input type="submit" value="Zaloguj">
            </form>
        </div>

        <!-- oraz czerwonego diva, ze nie jestesmy zalogowani -->
        <div class="status wylogowany">
            <span>Wylogowany</span>
        </div>
    
    <?php

    }

    //a jezeli zmienna "zalogowany" jest ustawiona, i jej wartosc wynosi 1
    else if(isset($_SESSION['zalogowany']) && $_SESSION['zalogowany'] == 1){
    ?>
        <!-- to wyswietl przycisk wylogowania -->
        <div class="logowanie">
            <form action="wyloguj.php" method="post">
                <input type="submit" value="Wyloguj">
            </form>
        </div>
        
        <!-- oraz zielonego diva z trescia "zalogowany" -->
        <div class="status zalogowany">
            <span>Zalogowany</span>
        </div>



    <?php

    }

    ?>
</body>
<script src="main.js"></script>
</html>