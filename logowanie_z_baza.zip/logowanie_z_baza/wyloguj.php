<?php
//niezbedne polecenie, tworzy sesje
session_start();

//teraz "usuwamy" "cala" sesje oraz jej zmienne
session_unset();

//i wracamy na index.php
header("location:index.php");
?>